﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Robot_Wars;
using System.Text.RegularExpressions;

namespace Robot_Wars.Tests
{
    public class Grid
    {
        [Theory]
        [InlineData("10 10")]
        public void SetGrid_ValidString(string input)
        {
            bool expected = true;
            bool actual = Robot_Wars.Grid.IsGridStringValid(input);
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData("10d 10")]
        [InlineData("1010")]
        public void SetGrid_InvalidString(string input)
        {
            bool expected = false;
            bool actual = Robot_Wars.Grid.IsGridStringValid(input);
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData("10 10")]
        [InlineData("10000 10")]
        public void SetGrid_WithinTypeBoundaries(string input)
        {
            bool expected = true;
            bool actual = Robot_Wars.Grid.IsGridDimensionsValid(input);
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData("-10 10")]
        [InlineData("10000000 10")]
        public void SetGrid_OutsideTypeBoundaries(string input)
        {
            bool expected = false;
            bool actual = Robot_Wars.Grid.IsGridDimensionsValid(input);
            Assert.Equal(expected, actual);
        }
    }
}
