﻿using System.Windows;
using Xunit;

namespace Robot_Wars.Tests
{
    public class Robot
    {
        [Theory]
        [InlineData("10 10 E")]
        public void SetInitialState_ValidString(string input)
        {
            bool expected = true;
            bool actual = Robot_Wars.Robot.IsInitialstateStringValid(input);
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData("10 10 H")]
        public void SetInitialState_InvalidString(string input)
        {
            bool expected = false;
            bool actual = Robot_Wars.Robot.IsInitialstateStringValid(input);
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData("10 10 H", 10, 10)]
        public void IsInitialPositionValid(string initialstate, ushort width, ushort length)
        {
            Robot_Wars.Grid.Width = width;
            Robot_Wars.Grid.Length = length;
            bool actual = Robot_Wars.Robot.IsInitialstatePositionValid(initialstate);
            Assert.True(actual);
        }
        [Theory]
        [InlineData("10 10 H", 20, 20)]
        public void IsInitialPositionValid2(string initialstate, ushort width, ushort length)
        {
            Robot_Wars.Grid.Width = width;
            Robot_Wars.Grid.Length = length;
            bool actual = Robot_Wars.Robot.IsInitialstatePositionValid(initialstate);
            Assert.True(actual);
        }
        [Theory]
        [InlineData("10 10 H", 5, 4)]
        public void IsInitialPositionInvalid(string initialstate, ushort width, ushort length)
        {
            Robot_Wars.Grid.Width = width;
            Robot_Wars.Grid.Length = length;
            bool actual = Robot_Wars.Robot.IsInitialstatePositionValid(initialstate);
            Assert.False(actual);
        }
        [Theory]
        [InlineData("LMMRMRRMM")]
        public void IsInstructionsStringValid(string instructions)
        {
            bool actual = Robot_Wars.Robot.IsInstructionsStringValid(instructions);
            Assert.True(actual);
        }
        [Theory]
        [InlineData("LMMRMRPRMM")]
        public void IsInstructionsStringInvalid(string instructions)
        {
            bool actual = Robot_Wars.Robot.IsInstructionsStringValid(instructions);
            Assert.False(actual);
        }
        [Theory]
        [InlineData("L")]
        public void MoveRobotLeft_WhenWithinBorders(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(5, 5);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.North;
            var currentDirectionExpected = Robot_Wars.Robot.West;
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(currentDirectionExpected, Robot_Wars.Robot.currentDirection);
        }
        [Theory]
        [InlineData("R")]
        public void MoveRobotRight_WhenWithinBorders(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(5, 5);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.North;
            var currentDirectionExpected = Robot_Wars.Robot.East;
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(currentDirectionExpected, Robot_Wars.Robot.currentDirection);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_NorthWhenOnTopBorder(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(5, 20);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.North;
            var expected = new Vector(5, 20);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_SouthWhenOnBottomBorder(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(5, 0);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.South;
            var expected = new Vector(5, 0);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }

        [Theory]
        [InlineData("M")]
        public void MoveRobot_EastWhenOnRightBorder(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(20, 8);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.East;
            var expected = new Vector(20, 8);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_WestWhenOnLeftBorder(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(0, 10);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.West;
            var expected = new Vector(0, 10);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_ToNorthWithinBorders(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(10, 10);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.North;
            var expected = new Vector(10, 11);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_ToSouthWithinBorders(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(10, 10);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.South;
            var expected = new Vector(10, 9);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_ToEastWithinBorders(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(10, 10);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.East;
            var expected = new Vector(11, 10);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("M")]
        public void MoveRobot_ToWestWithinBorders(string instructions)
        {
            Robot_Wars.Grid.Width = 20;
            Robot_Wars.Grid.Length = 20;
            Robot_Wars.Robot.currentPosition = new Vector(10, 10);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.West;
            var expected = new Vector(9, 10);
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal(expected, Robot_Wars.Robot.currentPosition);
        }
        [Theory]
        [InlineData("MMRMMRMRRM")]
        public void MoveRobot_FinalTest(string instructions)
        {
            Robot_Wars.Grid.Width = 5;
            Robot_Wars.Grid.Length = 5;
            Robot_Wars.Robot.currentPosition = new Vector(3, 3);
            Robot_Wars.Robot.currentDirection = Robot_Wars.Robot.East;
            var result = Robot_Wars.Robot.MoveRobot(instructions);
            Assert.Equal("5 1 E", result);
        }
    }
}
